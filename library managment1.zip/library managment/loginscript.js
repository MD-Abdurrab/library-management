<script>
function myFunction()
{
var uname = document.forms["login-form"]["uname"].value;
var pass = document.forms["login-form"]["pass"].value;
if(uname=="staff" && pass=="1234")
{
window.location.href="home.html";
}
else
{
alert("Invalid UserName and Password");
}
if (password === pass) {
    window.location="home.html";
} else {
    alert('Password is not correct');
}
}
</script>
